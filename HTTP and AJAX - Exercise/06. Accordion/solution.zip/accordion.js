function solution() {
    const mainEl = document.querySelector('#main');
    const urlTitles = 'http://localhost:3030/jsonstore/advanced/articles/list';
    const urlArticles = 'http://localhost:3030/jsonstore/advanced/articles/details/';

    mainEl.innerHTML = ``;

    loadArticles();

    async function loadArticles() {
        const response = await fetch(urlTitles);
        const articles = await response.json();

        Object.values(articles).forEach((article) => {
            const newDivEl = document.createElement('div');
            newDivEl.className = 'accordion';

            newDivEl.innerHTML = `
                <div class="head">
                    <span>${article.title}</span>
                    <button class="button" id="${article._id}">More</button>
                </div>
                <div class="extra" style="display: none;"></div>
            `;
            mainEl.appendChild(newDivEl);
        });

        const buttons = mainEl.querySelectorAll('.button');
        buttons.forEach((button) => {
            button.addEventListener('click', toggleContent);
        });
    }

    async function toggleContent(e) {
        const button = e.target;
        const articleId = button.id;
        const extraDiv = button.parentElement.nextElementSibling;

        if (button.textContent === 'More') {
            if (!extraDiv.querySelector('p')) {
                try {
                    const response = await fetch(`${urlArticles}${articleId}`);
                    if (!response.ok) throw new Error('Failed to fetch article details');
                    const article = await response.json();
                    const contentP = document.createElement('p');
                    contentP.textContent = article.content;
                    extraDiv.appendChild(contentP);
                } catch (error) {
                    extraDiv.innerHTML = '<p>Error loading content.</p>';
                }
            }
            extraDiv.style.display = 'block';
            button.textContent = 'Less';
        } else {
            extraDiv.style.display = 'none';
            button.textContent = 'More';
        }
    }
}

solution();
